package com.practice.database.entities

import com.practice.database.Database
import com.practice.database.entities.ItemDto.Companion.STATUS_WAIT
import kotlinx.datetime.Clock
import kotlinx.datetime.Instant
import org.jetbrains.exposed.dao.IntEntity
import org.jetbrains.exposed.dao.IntEntityClass
import org.jetbrains.exposed.dao.id.EntityID
import org.jetbrains.exposed.dao.id.IntIdTable
import org.jetbrains.exposed.sql.kotlin.datetime.timestamp
import java.util.concurrent.TimeUnit

@kotlinx.serialization.Serializable
data class ItemDto(


    val id: Int? = null,
    val userId: Int? = null,
    val userNickName: String? = null,
    val status: Byte? = null,
    val category: Byte? = null,
    val name: String? = null,
    val description: String? = null,
    val period: Byte? = null,
    val minPeople: Int? = null,
    var people: Int? = null,
    val startPrice: Long? = null,
    val okPrice: Long? = null,
    val currentPrice: Long? = null,
    val likes: Int? = null,
    val createdAt: Instant? = null,
    val willEndAt: Instant? = null,
    val lastEvalAt: Instant? = null,
    var isMine: Boolean = false
) {
    companion object {
        const val STATUS_WAIT: Byte = 0
        const val STATUS_CONTINUE: Byte = 1
        const val STATUS_END: Byte = 2
        const val STATUS_FLEX: Byte = 3

        const val CATEGORY_BAG: Byte = 0
        const val CATEGORY_SHOES: Byte = 1
        const val CATEGORY_ACCESSORY: Byte = 2
        const val CATEGORY_ELECTRONICS: Byte = 3
        const val CATEGORY_FURNITURE: Byte = 4
        const val CATEGORY_CLOTH: Byte = 5
        const val CATEGORY_CAR: Byte = 6
        const val CATEGORY_SPORT: Byte = 7
        const val CATEGORY_HOBBY: Byte = 8
        const val CATEGORY_ETC: Byte = 9

        const val PERIOD_12_HOURS = 0
        const val PERIOD_24_HOURS = 1
        const val PERIOD_48_HOURS = 2
        const val PERIOD_72_HOURS = 3
        const val PERIOD_1_WEEKS = 4

        val PERIOD_MAP = mapOf(
            PERIOD_12_HOURS to TimeUnit.HOURS.toMillis(12),
            PERIOD_24_HOURS to TimeUnit.HOURS.toMillis(24),
            PERIOD_48_HOURS to TimeUnit.HOURS.toMillis(48),
            PERIOD_72_HOURS to TimeUnit.HOURS.toMillis(72),
            PERIOD_1_WEEKS to TimeUnit.DAYS.toMillis(7)
        )

        const val MIN_PEOPLE_3 = 0
        const val MIN_PEOPLE_5 = 1
        const val MIN_PEOPLE_10 = 2
        const val MIN_PEOPLE_20 = 3
        const val MIN_PEOPLE_50 = 4

        val PEOPLE_MAP = mapOf(
            MIN_PEOPLE_3 to 3,
            MIN_PEOPLE_5 to 5,
            MIN_PEOPLE_10 to 10,
            MIN_PEOPLE_20 to 20,
            MIN_PEOPLE_50 to 50
        )
    }
}


object Items : IntIdTable() {



    val user = reference("user", Users)
    val status = byte("status").default(STATUS_WAIT)
    val category = byte("category")
    val name = varchar("name", 40)
    val description = varchar("description", 2000)
    val period = byte("period")
    val minPeople = integer("minPeople")
    val startPrice = long("startPrice")
    val okPrice = long("okPrice").nullable()
    val currentPrice = long("currentPrice")
    val likes = integer("likes").default(0)
    val createdAt = timestamp("createdAt").clientDefault { Clock.System.now() }
    val willEndAt = timestamp("willEndAt").nullable()
    val lastEvalAt = timestamp("lastEvalAt").clientDefault { Clock.System.now() }
}

class Item(id: EntityID<Int>) : IntEntity(id) {
    companion object : IntEntityClass<Item>(Items)

    var user by User referencedOn Items.user
    var userId by Items.user
    var status by Items.status
    var category by Items.category
    var name by Items.name
    var description by Items.description
    var period by Items.period
    var minPeople by Items.minPeople
    var startPrice by Items.startPrice
    var okPrice by Items.okPrice
    var currentPrice by Items.currentPrice
    var likes by Items.likes
    var createdAt by Items.createdAt
    var willEndAt by Items.willEndAt
    var lastEvalAt by Items.lastEvalAt

    fun getAuctionSize() = Database.findAuctions(id.value).size

    fun toDto() = ItemDto(
        id.value,
        userId.value,
        user.nickname,
        status, category, name, description, period, minPeople, getAuctionSize(),
        startPrice, okPrice, currentPrice, likes,
        createdAt, willEndAt, lastEvalAt
    )
}
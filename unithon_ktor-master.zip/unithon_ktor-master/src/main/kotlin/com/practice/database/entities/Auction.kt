package com.practice.database.entities

import org.jetbrains.exposed.dao.IntEntity
import org.jetbrains.exposed.dao.IntEntityClass
import org.jetbrains.exposed.dao.id.EntityID
import org.jetbrains.exposed.dao.id.IntIdTable

@kotlinx.serialization.Serializable
data class AuctionDto(


    val id: Int? = null,
    val userId: Int? = null,
    val itemId: Int? = null
) {
    companion object {
    }
}


object Auctions : IntIdTable() {

    val user = reference("user", Users)
    val item = reference("item", Items)
    init {
        uniqueIndex(user, item)
    }
}

class Auction(id: EntityID<Int>) : IntEntity(id) {
    companion object : IntEntityClass<Auction>(Auctions)

    var user by User referencedOn Auctions.user
    var userId by Auctions.user
    var item by Item referencedOn Auctions.item
    var itemId by Auctions.item

    fun toDto() = AuctionDto(
        id.value,
        userId.value,
        itemId.value
    )
}
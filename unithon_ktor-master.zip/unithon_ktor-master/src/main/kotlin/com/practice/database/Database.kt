package com.practice.database

import com.practice.*
import com.practice.database.entities.*
import io.ktor.server.application.*
import kotlinx.datetime.Clock
import kotlinx.datetime.DateTimeUnit
import kotlinx.datetime.plus
import org.jetbrains.exposed.dao.id.EntityID
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.Database
import org.jetbrains.exposed.sql.SqlExpressionBuilder.minus
import org.jetbrains.exposed.sql.SqlExpressionBuilder.plus
import org.jetbrains.exposed.sql.transactions.transaction


fun Application.configureDatabase() {
    Database.connect(
        "jdbc:mysql://$AWS_RDS_BASEURL:$AWS_RDS_PORT/unithon", driver = "com.mysql.cj.jdbc.Driver",
        user = AWS_RDS_USER, password = AWS_RDS_PASSWORD
    )
    transaction {
        SchemaUtils.createMissingTablesAndColumns(Users, Items, Auctions)
    }
}

object Database {
    fun findUserByKakaoId(kakaoId: Long) = transaction {
        User.find {
            Users.kakaoId eq kakaoId
        }.firstOrNull()
    }

    fun findUserByUserId(userId: Int) = transaction {
        User.find {
            Users.id eq userId
        }.firstOrNull()
    }

    fun createUserByNickname(kakaoId: Long, nickname: String) = transaction {
        User.new {
            this.kakaoId = kakaoId
            this.nickname = nickname
        }
    }

    fun changeUserNickname(userId: Int, nickname: String) = transaction {
        Users.update({ Users.id eq userId }) {
            it[Users.nickname] = nickname
        }
    }
    fun findItem(itemId: Int) = transaction {
        Item.find {
            Items.id eq itemId
        }.firstOrNull()
    }
    fun findItemDto(itemId: Int) = transaction {
        Item.find {
            Items.id eq itemId
        }.firstOrNull()?.toDto()
    }

    fun findItems(category: Byte?, sort: String = SORT_RECENT, order: String = ORDER_DESC, limit: Int? = null, userId: Int? = null) =
        transaction {
            var iterable = category?.let {
                Item.find {
                    userId?.let { Items.user eq it }
                    Items.category eq it
                }
            } ?: run {
                userId?.let {
                    Item.find {
                        Items.user eq it
                    }
                } ?: Item.all()
            }
            limit?.let {
                iterable = iterable.limit(it)
            }
            iterable.run {
                when (sort) {
                    SORT_RECENT -> {
                        when (order) {
                            ORDER_DESC -> orderBy(Items.createdAt to SortOrder.DESC)
                            else -> orderBy(Items.createdAt to SortOrder.ASC)
                        }
                    }
                    SORT_LIKE -> {
                        when (order) {
                            ORDER_DESC -> orderBy(Items.likes to SortOrder.DESC)
                            else -> orderBy(Items.likes to SortOrder.ASC)
                        }
                    }
                    SORT_PRICE -> {
                        when (order) {
                            ORDER_DESC -> orderBy(Items.currentPrice to SortOrder.DESC)
                            else -> orderBy(Items.currentPrice to SortOrder.ASC)
                        }
                    }
                    else -> {
                        when (order) {
                            ORDER_DESC -> orderBy(Items.lastEvalAt to SortOrder.DESC)
                            else -> orderBy(Items.lastEvalAt to SortOrder.ASC)
                        }
                    }
                }
            }.map {
                it.toDto()
            }
        }

    fun createItem(
        userId: Int,
        category: Byte,
        name: String,
        description: String,
        period: Byte,
        minPeople: Int,
        startPrice: Long,
        okPrice: Long?
    ) = transaction {
        Item.new {
            this.userId = EntityID(userId, Users)
            this.category = category
            this.name = name
            this.description = description
            this.period = period
            this.minPeople = minPeople
            this.startPrice = startPrice
            this.okPrice = okPrice
            this.currentPrice = startPrice
        }
    }

    fun evaluateItem(
        userId: Int,
        winnerItemId: Int,
        loserItemId: Int
    ) = transaction {
        val currentTime = Clock.System.now()
        Users.update({Users.id eq userId}) {
            it[point] = point + 50
        }
        Items.update({ Items.id eq winnerItemId }) {
            it[likes] = likes + 1
            it[lastEvalAt] = currentTime
        }
        Items.update({ Items.id eq loserItemId }) {
            it[lastEvalAt] = currentTime
        }
    }

    fun createAuction(
        userId: Int,
        itemId: Int
    ): Auction? {
        val user = findUserByUserId(userId) ?: return null
        if (user.point < 500) {
            return null
        }
        val item = findItem(itemId) ?: return null
        return try {
            transaction {
                Users.update({Users.id eq userId}) {
                    it[point] = point - 500
                }
                val auction = Auction.new {
                    this.userId = EntityID(userId, Users)
                    this.itemId = EntityID(itemId, Items)
                }
                if (item.getAuctionSize() == ItemDto.PEOPLE_MAP.getValue(item.minPeople)) {
                    Items.update({ Items.id eq itemId }) {
                        it[status] = ItemDto.STATUS_CONTINUE
                        it[willEndAt] = Clock.System.now().plus(ItemDto.PERIOD_MAP.getValue(item.period.toInt()), DateTimeUnit.MILLISECOND)
                    }
                }
                auction
            }
        } catch (e: Exception) {
            null
        }

    }

    fun findAuction(userId: Int, itemId: Int) = transaction {
        Auction.find {
            (Auctions.user eq userId) and (Auctions.item eq itemId)
        }.firstOrNull()
    }

    fun findAuctions(itemId: Int) = transaction {
        Auction.find {
            Auctions.item eq itemId
        }.map {
            it.toDto()
        }
    }

    fun findAuctionsByUserId(userId: Int) = transaction {
        Auction.find {
            Auctions.user eq userId
        }
    }


}
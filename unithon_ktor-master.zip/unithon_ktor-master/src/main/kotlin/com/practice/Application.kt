package com.practice

import com.practice.database.configureDatabase
import com.practice.plugins.configureRouting
import com.practice.plugins.configureSecurity
import com.practice.plugins.configureSerialization
import io.ktor.server.engine.*
import io.ktor.server.netty.*

fun main() {

    embeddedServer(Netty, port = PORT, host = HOST) {
        configureDatabase()
        configureSecurity()
        configureRouting()
        configureSerialization()
    }.start(wait = true)
}

package com.practice.network.body.receive

@kotlinx.serialization.Serializable
data class EvaluateBody(
    val winnerItemId: Int,
    val loserItemId: Int
)

package com.practice.network.body.receive

@kotlinx.serialization.Serializable
data class ChangeNicknameBody(
    val nickname: String? = null
)
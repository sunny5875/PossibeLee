package com.practice.network.body.receive

@kotlinx.serialization.Serializable
data class RegisterAuctionBody(
    val itemId: Int? = null
)

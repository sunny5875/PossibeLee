package com.practice

const val SORT_RECENT = "recent"
const val SORT_LIKE = "like"
const val SORT_PRICE = "price"
const val SORT_LAST_EVAL = "lastEval"

const val ORDER_ASC = "asc"
const val ORDER_DESC = "desc"

const val TYPE_BUY = "buy"
const val TYPE_SELL = "sell"
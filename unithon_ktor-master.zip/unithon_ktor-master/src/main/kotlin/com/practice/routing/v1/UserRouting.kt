package com.practice.routing.v1

import com.practice.database.Database
import com.practice.network.body.receive.ChangeNicknameBody
import com.practice.plugins.getUserId
import com.practice.plugins.receive
import io.ktor.http.*
import io.ktor.server.application.*
import io.ktor.server.response.*
import io.ktor.server.routing.*

fun Route.userRouting() {
    get("me") {
        val user = Database.findUserByUserId(getUserId()) ?: return@get call.respondText("Not Found.", status = HttpStatusCode.NotFound)
        call.respond(user.toDto())
    }
    patch("nickname") {
        val changeNicknameBody: ChangeNicknameBody = receive() ?: return@patch call.respondText("Bad Request.", status = HttpStatusCode.BadRequest)
        changeNicknameBody.nickname?.let {
            Database.changeUserNickname(getUserId(), it)
        } ?: return@patch call.respondText("Bad Request.", status = HttpStatusCode.BadRequest)
        call.respond(HttpStatusCode.OK, "Changed")
    }
}
package com.practice.routing.v1

import com.practice.plugins.query
import io.ktor.http.*
import io.ktor.server.application.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import java.io.File

fun Route.uploadRouting() {
    get {
        val file = File("uploads/${query("filename")}")
        call.response.header(
            HttpHeaders.ContentDisposition,
            ContentDisposition.Attachment.withParameter(ContentDisposition.Parameters.FileName, "ktor_logo.png")
                .toString()
        )
        call.respondFile(file)
    }
}
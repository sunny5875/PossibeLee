package com.practice.routing

import com.practice.routing.v1.*
import io.ktor.server.auth.*
import io.ktor.server.routing.*

fun Route.v1Routing() {
    route("auth") {
        authRouting()
    }
    route("upload"){
        uploadRouting()
    }
    authenticate("auth-jwt") {
        route("user") {
            userRouting()
        }
        route("item") {
            itemRouting()
        }
        route("auction") {
            auctionRouting()
        }

    }

}
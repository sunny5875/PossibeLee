package com.practice.routing.v1

import com.practice.ORDER_DESC
import com.practice.SORT_RECENT
import com.practice.TYPE_BUY
import com.practice.TYPE_SELL
import com.practice.database.Database
import com.practice.database.entities.ItemDto
import com.practice.network.body.receive.EvaluateBody
import com.practice.plugins.getUserId
import com.practice.plugins.query
import com.practice.plugins.receive
import io.ktor.http.*
import io.ktor.http.content.*
import io.ktor.server.application.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import org.jetbrains.exposed.sql.transactions.transaction
import java.io.File

fun Route.itemRouting() {

    get {
        val itemId = query("itemId")?.toIntOrNull() ?: run {
            val category: Byte? = query("category")?.toByteOrNull()
            val sort = query("sort") ?: SORT_RECENT
            val order = query("order") ?: ORDER_DESC
            val limit = query("limit")?.toIntOrNull()
            return@get call.respond(Database.findItems(category, sort, order, limit))
        }
        val item = Database.findItemDto(itemId) ?: return@get call.respondText("Not Found.", status = HttpStatusCode.NotFound)
        Database.findAuction(getUserId(), itemId)?.let {
            item.isMine = true
        }
        call.respond(item)
    }

    get ("me") {
        val type = query("type") ?: return@get call.respondText("Bad Request.", status = HttpStatusCode.BadRequest)
        when (type) {
            TYPE_BUY -> {
                return@get call.respond(transaction {
                    Database.findAuctionsByUserId(getUserId()).map {
                        it.item.toDto()
                    }
                })
            }
            TYPE_SELL -> {
                val category: Byte? = query("category")?.toByteOrNull()
                val sort = query("sort") ?: SORT_RECENT
                val order = query("order") ?: ORDER_DESC
                val limit = query("limit")?.toIntOrNull()
                return@get call.respond(Database.findItems(category, sort, order, limit, getUserId()))
            }
        }
        return@get call.respondText("Bad Request.", status = HttpStatusCode.BadRequest)
    }


    post("register") {
        val item =
            receive<ItemDto>() ?: return@post call.respondText("Bad Request.", status = HttpStatusCode.BadRequest)
        with(item) {

            call.respond(transaction {
                Database.createItem(
                    getUserId(),
                    category!!,
                    name!!,
                    description!!,
                    period!!,
                    minPeople!!,
                    startPrice!!,
                    okPrice
                ).toDto()
            })
        }


    }

    post("registerTest") {
        val multipartData = call.receiveMultipart()

        multipartData.forEachPart { part ->
            when (part) {
                is PartData.FormItem -> {
                }
                is PartData.FileItem -> {
                    var fileBytes = part.streamProvider().readBytes()
                    File("uploads/${part.originalFileName}").writeBytes(fileBytes)
                }
            }
        }

        call.respondText("OK", status = HttpStatusCode.OK)
    }

    post("evaluate") {
        val evaluateBody: EvaluateBody = receive() ?: return@post call.respondText("Bad Request.", status = HttpStatusCode.BadRequest)
        Database.evaluateItem(getUserId(), evaluateBody.winnerItemId, evaluateBody.loserItemId)
        call.respondText("OK", status = HttpStatusCode.OK)
    }
}
package com.practice.routing.v1

import com.practice.database.Database
import com.practice.network.body.receive.RegisterAuctionBody
import com.practice.plugins.getUserId
import com.practice.plugins.receive
import io.ktor.http.*
import io.ktor.server.application.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import org.jetbrains.exposed.sql.transactions.transaction

fun Route.auctionRouting() {


    post("register") {
        val registerAuctionBody = receive<RegisterAuctionBody>() ?: return@post call.respondText("Bad Request", status = HttpStatusCode.BadRequest)
        Database.createAuction(getUserId(), registerAuctionBody.itemId!!) ?: return@post call.respondText("Bad Request", status = HttpStatusCode.BadRequest)

        call.respondText("OK", status = HttpStatusCode.OK)
    }
    get("me") {
        call.respond(transaction {
            Database.findAuctionsByUserId(getUserId()).map {
                it.toDto()
            }
        })
    }
}
package com.possiblee.kakaologin.view.login.main.mypage

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MyPointActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }
}
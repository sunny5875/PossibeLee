package com.possiblee.kakaologin.dto

import java.util.*


data class Comment (
    val userName: String? = null,
    val content: String? = null,
    val date: Date? = null
)
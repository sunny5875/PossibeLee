package com.possiblee.kakaologin.dto

import java.sql.Timestamp
import java.util.concurrent.TimeUnit

data class ItemDto(


    val id: Int? = null,
    val userId: Int? = null,
    val userNickName: String? = null,
    val status: Byte? = null,
    val category: Byte? = null,
    val name: String? = null,
    val description: String? = null,
    val period: Byte? = null,
    val minPeople: Int? = null,
    var people: Int? = null,
    val startPrice: Long? = null,
    val okPrice: Long? = null,
    val currentPrice: Long? = null,
    val likes: Int? = null,
    val createdAt: Timestamp? = null,
    val willEndAt: Timestamp? = null,
    val lastEvalAt: Timestamp? = null,
    var isMine: Boolean = false
) {
    companion object {
        const val STATUS_WAIT: Byte = 0
        const val STATUS_CONTINUE: Byte = 1
        const val STATUS_END: Byte = 2
        const val STATUS_FLEX: Byte = 3

        const val CATEGORY_BAG: Byte = 0
        const val CATEGORY_SHOES: Byte = 1
        const val CATEGORY_ACCESSORY: Byte = 2
        const val CATEGORY_ELECTRONICS: Byte = 3
        const val CATEGORY_FURNITURE: Byte = 4
        const val CATEGORY_CLOTH: Byte = 5
        const val CATEGORY_CAR: Byte = 6
        const val CATEGORY_SPORT: Byte = 7
        const val CATEGORY_HOBBY: Byte = 8
        const val CATEGORY_ETC: Byte = 9

        const val PERIOD_12_HOURS = 0
        const val PERIOD_24_HOURS = 1
        const val PERIOD_48_HOURS = 2
        const val PERIOD_72_HOURS = 3
        const val PERIOD_1_WEEKS = 4

        val PERIOD_MAP = mapOf(
            PERIOD_12_HOURS to TimeUnit.HOURS.toMillis(12),
            PERIOD_24_HOURS to TimeUnit.HOURS.toMillis(24),
            PERIOD_48_HOURS to TimeUnit.HOURS.toMillis(48),
            PERIOD_72_HOURS to TimeUnit.HOURS.toMillis(72),
            PERIOD_1_WEEKS to TimeUnit.DAYS.toMillis(7)
        )

        const val MIN_PEOPLE_3 = 0
        const val MIN_PEOPLE_5 = 1
        const val MIN_PEOPLE_10 = 2
        const val MIN_PEOPLE_20 = 3
        const val MIN_PEOPLE_50 = 4

        val PEOPLE_MAP = mapOf(
            MIN_PEOPLE_3 to 3,
            MIN_PEOPLE_5 to 5,
            MIN_PEOPLE_10 to 10,
            MIN_PEOPLE_20 to 20,
            MIN_PEOPLE_50 to 50
        )
    }
}
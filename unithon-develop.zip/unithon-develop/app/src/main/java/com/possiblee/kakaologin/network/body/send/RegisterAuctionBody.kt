package com.possiblee.kakaologin.network.body.send

data class RegisterAuctionBody(
    val itemId: Int? = null
)

package com.possiblee.kakaologin.view.login.main

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.possiblee.kakaologin.R
import com.possiblee.kakaologin.databinding.FragmentEarnPointBinding
import com.possiblee.kakaologin.dto.ItemDto
import com.possiblee.kakaologin.dto.ItemDto.Companion.STATUS_CONTINUE
import com.possiblee.kakaologin.dto.ItemDto.Companion.STATUS_WAIT
import com.possiblee.kakaologin.lib.*
import com.possiblee.kakaologin.network.RetrofitClient.evaluateItem
import com.possiblee.kakaologin.network.RetrofitClient.getItems
import com.possiblee.kakaologin.view.login.MainActivity
import splitties.bundle.putExtras
import splitties.fragments.start
import splitties.resources.color
import splitties.resources.drawable
import splitties.resources.str


class EarnPointFragment constructor() : Fragment() {


    private lateinit var bind: FragmentEarnPointBinding

    var itemList = arrayListOf<ItemDto>()
    var selectedIndex = -1

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bind = FragmentEarnPointBinding.inflate(inflater, container, false)
        with(bind) {

            cellAuctionEarnPoint1.itemDetailEarnPoint.setOnClickListener {
                start<AuctionPostActivity> {
                    putExtras(AuctionPostActivity.Extras) {
                        itemId = itemList[0].id!!
                    }
                }
            }
            cellAuctionEarnPoint2.itemDetailEarnPoint.setOnClickListener {
                start<AuctionPostActivity> {
                    putExtras(AuctionPostActivity.Extras) {
                        itemId = itemList[1].id!!
                    }
                }
            }
            cellAuctionEarnPoint1.root.setOnClickListener {
                selectedIndex = 0
                cellAuctionEarnPoint2.root.background =
                    drawable(R.drawable.bg_common_button_filter)
                cellAuctionEarnPoint1.root.background =
                    drawable(R.drawable.bg_common_item_earn_selected)
                // TODO: 첫번째 클릭
                selectButtonEarnPoint.show()
            }
            cellAuctionEarnPoint2.root.setOnClickListener {
                selectedIndex = 1
                cellAuctionEarnPoint1.root.background =
                    drawable(R.drawable.bg_common_button_filter)
                cellAuctionEarnPoint2.root.background =
                    drawable(R.drawable.bg_common_item_earn_selected)
                // TODO: 두번째 클릭
                selectButtonEarnPoint.show()
            }
            selectButtonEarnPoint.setOnClickListener {
                it.gone()
                cellAuctionEarnPoint1.root.gone()
                cellAuctionEarnPoint1.root.background =
                    drawable(R.drawable.bg_common_button_filter)
                cellAuctionEarnPoint2.root.gone()
                cellAuctionEarnPoint2.root.background =
                    drawable(R.drawable.bg_common_button_filter)
                requireActivity().evaluateItem(
                    itemList[selectedIndex].id!!,
                    itemList[1 - selectedIndex].id!!
                ) { _, _ ->
                    refresh()
                    (requireActivity() as MainActivity).refresh()
                }
            }


            refresh()
            return root
        }
    }


    companion object {
        fun newInstance() = EarnPointFragment()
    }

    fun refresh() {
        selectedIndex = -1
        bind.selectButtonEarnPoint.gone()
        requireActivity().run {
            getItems(sort = SORT_LAST_EVAL, limit = 2, order = ORDER_ASC) { _, response ->
                itemList = response.body()!!
                if (itemList.size != 2) {
                    // todo 아이템이 두개가 안될때 불가능하다는 표시
                } else {
                    with(bind.cellAuctionEarnPoint1) {
                        val item = itemList[0]
                        itemTitleEarnPoint.text = item.name
                        currentPriceEarnPoint.text = formattedPoint(item.currentPrice)
                        itemParticipantTextEarnPoint.text =
                            str(R.string.participantNumber, 0, item.minPeople)
                        if(item.status == STATUS_WAIT){
                            remainTimeImgEarnPoint.setTint(color(splitties.material.colors.R.color.blue_grey_400))
                            remainTimeEarnPoint.text = str(R.string.remainTime, item.period)
                        }else if(item.status == STATUS_CONTINUE){
                            remainTimeImgEarnPoint.setTint(color(splitties.material.colors.R.color.yellow_600))
                            remainTimeEarnPoint.text = "${item.willEndAt}시간 남음"
                        }
                        Glide.with(requireActivity()).load("${BASE_URL}v1/upload?filename=${item.id!!}")
                            .into(itemImageEarnPoint)
                        root.show()
                    }
                    with(bind.cellAuctionEarnPoint2) {
                        val item = itemList[1]
                        itemTitleEarnPoint.text = item.name
                        currentPriceEarnPoint.text = formattedPoint(item.currentPrice)
                        itemParticipantTextEarnPoint.text =
                            str(R.string.participantNumber, 0, item.minPeople)
                        Glide.with(requireActivity()).load("${BASE_URL}v1/upload?filename=${item.id!!}")
                            .into(itemImageEarnPoint)
                        root.show()
                    }
                }
            }
        }
    }


}
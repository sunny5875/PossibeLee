package com.possiblee.kakaologin.view.login.main

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.possiblee.kakaologin.R
import com.possiblee.kakaologin.databinding.FragmentExchangeBinding
import com.possiblee.kakaologin.lib.*
import com.possiblee.kakaologin.network.RetrofitClient.getMyItems
import com.possiblee.kakaologin.view.login.main.exchange.BuyFragment
import com.possiblee.kakaologin.view.login.main.exchange.SellFragment
import com.possiblee.kakaologin.view.login.main.home.search.ItemAdapter
import splitties.resources.color


class ExchangeFragment constructor() : Fragment() {


    private lateinit var bind: FragmentExchangeBinding

    private val buyFragment by lazy {
        BuyFragment.newInstance()
    }

    private val sellFragment by lazy {
        SellFragment.newInstance()
    }

    private val itemAdapter by lazy {
        ItemAdapter(requireActivity())
    }
    private var isInit = false

    private var currentTab = TYPE_BUY

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bind = FragmentExchangeBinding.inflate(inflater, container, false)

        with(bind) {
            requireActivity().let {
                isInit = true
                buyConstraintLayout.setOnClickListener {
                    buyButtonFilter.setTextColor(
                        it.color(R.color.color_red)
                    )
                    buyUnderBarConstraintLayout.show()
                    sellButtonFIlter.setTextColor(
                        it.color(R.color.color_red_deactivated)
                    )
                    sellUnderbarConstraintLayout.gone()
                    currentTab = TYPE_BUY
                    refresh()
                }
                sellConstraintLayout.setOnClickListener {
                    sellButtonFIlter.setTextColor(
                        it.color(R.color.color_red)
                    )
                    sellUnderbarConstraintLayout.show()
                    buyButtonFilter.setTextColor(
                        it.color(R.color.color_red_deactivated)
                    )
                    buyUnderBarConstraintLayout.gone()
                    currentTab = TYPE_SELL
                    refresh()

                }

                beforeButton.setOnClickListener {
                }

                ingButton.setOnClickListener {

                }

                doneButton.setOnClickListener {

                }
                itemRecycler.adapter = itemAdapter
                filteredGroup.setOnCheckedChangeListener { radioGroup, i ->
                    refresh()
                }
            }
            return root
        }
    }

    override fun onHiddenChanged(hidden: Boolean) {
        super.onHiddenChanged(hidden)
        if (isInit && !hidden) {
            refresh()
        }
    }

    override fun onStart() {
        super.onStart()
        if (isInit) {
            refresh()
        }
    }

    companion object {
        fun newInstance() = ExchangeFragment()
    }

    fun refresh() {
        requireActivity().getMyItems(currentTab) { _, response ->
            itemAdapter.refresh(response.body()!!, bind.filteredGroup.checkedIndex().toString())
        }
    }


}
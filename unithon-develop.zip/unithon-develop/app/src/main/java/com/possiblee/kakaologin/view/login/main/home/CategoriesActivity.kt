package com.possiblee.kakaologin.view.login.main.home

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.possiblee.kakaologin.R
import com.possiblee.kakaologin.common.view.CategoryItemView
import com.possiblee.kakaologin.databinding.ActivityCategoriesBinding
import com.possiblee.kakaologin.dto.MutableByte
import com.possiblee.kakaologin.lib.*
import com.possiblee.kakaologin.network.RetrofitClient.getItems
import com.possiblee.kakaologin.view.login.MainActivity
import com.possiblee.kakaologin.view.login.main.home.search.ItemAdapter
import splitties.bundle.BundleSpec
import splitties.bundle.bundle
import splitties.bundle.withExtras
import splitties.resources.drawable

class CategoriesActivity : AppCompatActivity() {
    private val bind by lazy {
        ActivityCategoriesBinding.inflate(layoutInflater)
    }

    object Extras : BundleSpec() {
        var index: Byte by bundle()
    }

    private val index by lazy {
        withExtras(Extras) {
            index
        }
    }

    private val categoriesAdapter by lazy {
        ItemAdapter(this@CategoriesActivity)
    }

    private val checkedIndex by lazy {
        MutableByte(index)
    }

    private val checkedOrderIndex
        get() = bind.cellFilterLayoutCategories.periodRadioGroupCategories.checkedIndex()

    val onCheckedListener = { categoryItemView: CategoryItemView? ->
        var sort: String? = null
        var order: String? = null
        when (checkedOrderIndex) {
            0 -> {
                sort = SORT_RECENT
                order = ORDER_DESC
            }
            1 -> {
                sort = SORT_LIKE
                order = ORDER_DESC
            }
            2 -> {
                sort = SORT_PRICE
                order = ORDER_DESC
            }
            3 -> {
                sort = SORT_RECENT
                order = ORDER_ASC
            }
        }
        getItems(checkedIndex.value, sort = sort, order = order) { _, response ->
            categoriesAdapter.refresh(response.body()!!)
            categoryItemView?.mBackground =
                drawable(R.drawable.bg_common_button_categories_selected)
            categoryItemView?.mNameText?.let { bind.titleText.text = it }
            bind.cellFilterLayoutCategories.periodRadioGroupCategories.isClickable = true
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        with(bind) {
            setContentView(root)
            cellFilterLayoutCategories.periodRadioGroupCategories.setOnCheckedChangeListener { radioGroup, i ->
                radioGroup.isClickable = false
                onCheckedListener(null)
            }
            onCheckedListener(cellCategoriesLayout.getContainer().getChildAt(index.toInt()) as CategoryItemView)
            cellCategoriesLayout.setChildrenOnclickListener(checkedIndex, {
                it.mBackground =
                    drawable(R.drawable.bg_common_button_categories)

            }) {
                onCheckedListener(it)
            }

            // 제목
            //  titleText.text = selectedItem.mNameText

            // 뒤로 가기
            backButtonCategories.setOnClickListener {
                finish()
            }
            // 카테고리 클릭

            // adpater
            auctionRecyclerCategories.adapter = categoriesAdapter

        }

    }


}
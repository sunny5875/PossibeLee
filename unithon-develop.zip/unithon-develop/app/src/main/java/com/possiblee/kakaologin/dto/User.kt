package com.possiblee.kakaologin.dto

data class User(
    val id: Int? = null,
    val kakaoId: Long? = null,
    val nickname: String? = null,
    val point: Long? = null
)

package com.possiblee.kakaologin.preference

import splitties.preferences.Preferences

object UserPreferences : Preferences("userState") {
    var serverAccessToken by StringOrNullPref("serverAccessToken", null)
}
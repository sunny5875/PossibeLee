package com.possiblee.kakaologin.network

import android.app.Activity
import android.graphics.Bitmap
import com.possiblee.kakaologin.dto.AuctionDto
import com.possiblee.kakaologin.dto.ItemDto
import com.possiblee.kakaologin.dto.User
import com.possiblee.kakaologin.lib.BASE_URL
import com.possiblee.kakaologin.lib.log
import com.possiblee.kakaologin.lib.toRequestBody
import com.possiblee.kakaologin.network.api.ServerApi
import com.possiblee.kakaologin.network.body.KakaoLoginBody
import com.possiblee.kakaologin.network.body.SignUpBody
import com.possiblee.kakaologin.network.body.send.ChangeNicknameBody
import com.possiblee.kakaologin.network.body.send.EvaluateBody
import com.possiblee.kakaologin.network.body.send.RegisterAuctionBody
import com.possiblee.kakaologin.preference.UserPreferences
import com.possiblee.kakaologin.view.LoginActivity
import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import splitties.activities.start

object RetrofitClient {
    private val instance = Retrofit.Builder().baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create()).build().create(ServerApi::class.java)

    val serverAccessToken
        get() = "Bearer ${UserPreferences.serverAccessToken}"


    fun Activity.kakaoLogin(
        kakaoAccessToken: String,
        onUnsuccessful: ((Call<KakaoLoginBody>, Response<KakaoLoginBody>) -> Unit)? = null,
        onSuccessful: (Call<KakaoLoginBody>, Response<KakaoLoginBody>) -> Unit
    ) = instance.kakaoLogin(KakaoLoginBody(kakaoAccessToken))
        .enqueue(defaultCallback(onUnsuccessful, onSuccessful))

    fun Activity.signUp(
        kakaoAccessToken: String,
        nickname: String,
        onUnsuccessful: ((Call<SignUpBody>, Response<SignUpBody>) -> Unit)? = null,
        onSuccessful: (Call<SignUpBody>, Response<SignUpBody>) -> Unit
    ) = instance.signUp(SignUpBody(kakaoAccessToken = kakaoAccessToken, nickname = nickname))
        .enqueue(defaultCallback(onUnsuccessful, onSuccessful))

    fun Activity.getCurrentUser(
        onUnsuccessful: ((Call<User>, Response<User>) -> Unit)? = null,
        onSuccessful: (Call<User>, Response<User>) -> Unit
    ) = instance.getCurrentUser(serverAccessToken)
        .enqueue(defaultCallback(onUnsuccessful, onSuccessful))

    fun Activity.changeNickname(
        nickname: String,
        onUnsuccessful: ((Call<Void>, Response<Void>) -> Unit)? = null,
        onSuccessful: (Call<Void>, Response<Void>) -> Unit
    ) = instance.changeNickname(serverAccessToken, ChangeNicknameBody(nickname))
        .enqueue(defaultCallback(onUnsuccessful, onSuccessful))

    fun Activity.getItem(
        itemId: Int,
        onUnsuccessful: ((Call<ItemDto>, Response<ItemDto>) -> Unit)? = null,
        onSuccessful: (Call<ItemDto>, Response<ItemDto>) -> Unit
    ) = instance.getItem(serverAccessToken, itemId)
        .enqueue(defaultCallback(onUnsuccessful, onSuccessful))

    fun Activity.getItems(
        category: Byte? = null,
        sort: String? = null,
        order: String? = null,
        limit: Int? = null,
        onUnsuccessful: ((Call<ArrayList<ItemDto>>, Response<ArrayList<ItemDto>>) -> Unit)? = null,
        onSuccessful: (Call<ArrayList<ItemDto>>, Response<ArrayList<ItemDto>>) -> Unit
    ) = instance.getItems(serverAccessToken, category, sort, order, limit)
        .enqueue(defaultCallback(onUnsuccessful, onSuccessful))

    fun Activity.getMyItems(
        type: String,
        onUnsuccessful: ((Call<ArrayList<ItemDto>>, Response<ArrayList<ItemDto>>) -> Unit)? = null,
        onSuccessful: (Call<ArrayList<ItemDto>>, Response<ArrayList<ItemDto>>) -> Unit
    ) = instance.getMyItems(serverAccessToken, type)
        .enqueue(defaultCallback(onUnsuccessful, onSuccessful))

    fun Activity.registerItem(
        category: Byte?,
        name: String,
        description: String,
        period: Byte,
        minPeople: Int,
        startPrice: Long,
        okPrice: Long?,
        onUnsuccessful: ((Call<ItemDto>, Response<ItemDto>) -> Unit)? = null,
        onSuccessful: (Call<ItemDto>, Response<ItemDto>) -> Unit
    ) = instance.registerItem(serverAccessToken, ItemDto(category = category ?: ItemDto.CATEGORY_ETC,name = name, description = description, period = period, minPeople = minPeople, startPrice = startPrice, okPrice = okPrice),
    )
        .enqueue(defaultCallback(onUnsuccessful, onSuccessful))

    fun Activity.registerTestItem(
        itemId: Int,
        image: Bitmap,
        onUnsuccessful: ((Call<Void>, Response<Void>) -> Unit)? = null,
        onSuccessful: (Call<Void>, Response<Void>) -> Unit
    ) = instance.registerTestItem(serverAccessToken, MultipartBody.Part.createFormData("image", "$itemId", image.toRequestBody()))
        .enqueue(defaultCallback(onUnsuccessful, onSuccessful))

    fun Activity.evaluateItem(
        winnerItemId: Int,
        loserItemId: Int,
        onUnsuccessful: ((Call<Void>, Response<Void>) -> Unit)? = null,
        onSuccessful: (Call<Void>, Response<Void>) -> Unit
    ) = instance.evaluateItem(serverAccessToken, EvaluateBody(winnerItemId, loserItemId))
        .enqueue(defaultCallback(onUnsuccessful, onSuccessful))

    fun Activity.registerAuction(
        itemId: Int,
        onUnsuccessful: ((Call<Void>, Response<Void>) -> Unit)? = null,
        onSuccessful: (Call<Void>, Response<Void>) -> Unit
    ) = instance.registerAuction(serverAccessToken, RegisterAuctionBody(itemId))
        .enqueue(defaultCallback(onUnsuccessful, onSuccessful))

    fun Activity.getMyAuctions(
        onUnsuccessful: ((Call<ArrayList<AuctionDto>>, Response<ArrayList<AuctionDto>>) -> Unit)? = null,
        onSuccessful: (Call<ArrayList<AuctionDto>>, Response<ArrayList<AuctionDto>>) -> Unit
    ) = instance.getMyAuctions(serverAccessToken)
        .enqueue(defaultCallback(onUnsuccessful, onSuccessful))



    private fun <T> Activity.defaultCallback(
        onUnsuccessful: ((Call<T>, Response<T>) -> Unit)?,
        onSuccessful: (Call<T>, Response<T>) -> Unit
    ) = object : Callback<T> {

        override fun onResponse(call: Call<T>, response: Response<T>) {
            if (response.isSuccessful) {
                onSuccessful(call, response)
            } else {
                onUnsuccessful?.run {
                    this(call, response)
                } ?: let {
                    if (response.code() == 401) {
                        log("here")
                        UserPreferences.serverAccessToken = null
                        start<LoginActivity>()
                        finish()
                    } else {
                        log("실패: $response")
                    }
                }
            }
        }

        override fun onFailure(call: Call<T>, t: Throwable) {
            log("Fail: ${t.message}")
        }

    }
}
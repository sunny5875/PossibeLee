package com.possiblee.kakaologin.dto

import java.sql.Date

data class Item (
    val id : Int? = null,
    val name: String? = null,
    val joinNum: Int? = null,
    val currentNum : Int = 0,
    val description: String? = null,
    val currentPrice: Int? = null,
    val likeNum : Int? = null,
    val limitTime : Date? = null,
    val commentNum : Int? = null
)
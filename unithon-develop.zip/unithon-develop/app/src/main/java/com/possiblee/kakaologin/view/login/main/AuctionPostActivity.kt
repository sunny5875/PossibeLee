package com.possiblee.kakaologin.view.login.main

import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputMethodManager
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.firebase.database.ChildEventListener
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ktx.getValue
import com.possiblee.kakaologin.R
import com.possiblee.kakaologin.databinding.ActivityAuctionPostBinding
import com.possiblee.kakaologin.databinding.BtmsheetOkPriceBinding
import com.possiblee.kakaologin.dto.Comment
import com.possiblee.kakaologin.dto.ItemDto
import com.possiblee.kakaologin.dto.ItemDto.Companion.STATUS_FLEX
import com.possiblee.kakaologin.dto.User
import com.possiblee.kakaologin.lib.*
import com.possiblee.kakaologin.network.RetrofitClient.getCurrentUser
import com.possiblee.kakaologin.network.RetrofitClient.getItem
import com.possiblee.kakaologin.network.RetrofitClient.registerAuction
import com.possiblee.kakaologin.network.fireReference
import com.possiblee.kakaologin.view.login.main.home.CommentAdapter
import splitties.bundle.BundleSpec
import splitties.bundle.bundle
import splitties.bundle.withExtras
import splitties.resources.color
import splitties.resources.str

class AuctionPostActivity : AppCompatActivity() {

    private val bind by lazy {
        ActivityAuctionPostBinding.inflate(layoutInflater)
    }

    object Extras : BundleSpec() {
        var itemId: Int by bundle()
    }

    private val itemId by lazy {
        withExtras(Extras) {
            itemId
        }
    }

    // 경매 신청 창
    private val applyAuctionBind by lazy { BtmsheetOkPriceBinding.inflate(layoutInflater) }
    private val applyAuctionDialog by lazy { BottomSheetDialog(this) }

    // 즉시 구매 창
    private val buyNowBind by lazy { BtmsheetOkPriceBinding.inflate(layoutInflater) }
    private val buyNowDialog by lazy { BottomSheetDialog(this) }

    private var user: User? = null

    val adapter = CommentAdapter(this)



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        with(bind) {
            setContentView(root)
            recyclerView.adapter = adapter
            Glide.with(this@AuctionPostActivity).load("${BASE_URL}v1/upload?filename=$itemId").into(itemImagePost)
            getItem(itemId) { _, response ->
                val item = response.body() ?: return@getItem
                titleTextPost.text = item.name
                sellerNickNameTextPost.text = item.userNickName
                likeCountTextPost.text = item.likes.toString()
                currentPointTextPost.text = formattedPoint(item.currentPrice)
                if (item.okPrice == null) {
                    okPointText.text = "즉시 구매 불가"
                    buyNowTextPost.setTextColor(
                        ContextCompat.getColor(
                            this@AuctionPostActivity,
                            splitties.material.colors.R.color.grey_400
                        )
                    )
                    buyNowTextPost.isClickable = false
                } else {
                    okPointText.text = formattedPoint(item.okPrice)
                }

                descriptionTextPost.text = item.description
                log(item)
                if (!item.isMine) {
                    applyAuctionTextPost.show()
                }
                peopleNumTextPost.text =
                    str(R.string.participantNumber, item.people, ItemDto.PEOPLE_MAP.getValue(item.minPeople!!))
//                timeTextPost.text = str(R.string.remainTime, item.willEndAt)
                if (item.willEndAt == null) {
                    timeTextPost.text = "경매 시작 전"
                    timeImagePost.setTint(R.color.blue_grey_400)
                } else {

                    val time = (item.willEndAt.time - System.currentTimeMillis()) / 1000 / 60 / 60

                    timeTextPost.text = "${time}시간"
                }

                if (item.category == STATUS_FLEX) {
                    peopleNumTextPost.gone()
                    peopleNumImagePost.visibility = View.GONE
                    timeImagePost.visibility = View.GONE
                    startPointImagePost.visibility = View.GONE
                    okPointText.visibility = View.GONE
                    peopleNumTextPost.visibility = View.GONE
                    timeTextPost.visibility = View.GONE
                    buyNowTextPost.visibility = View.GONE
                    applyAuctionTextPost.visibility = View.GONE

                }
            }



            applyAuctionDialog.setContentView(applyAuctionBind.root)
            buyNowDialog.setContentView(buyNowBind.root)

            fireReference("comments/${itemId}").addChildEventListener(object : ChildEventListener {
                override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                    adapter.addComment(snapshot.getValue<Comment>()!!)
                }

                override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {
                    TODO("Not yet implemented")
                }

                override fun onChildRemoved(snapshot: DataSnapshot) {
                    TODO("Not yet implemented")
                }

                override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {
                    TODO("Not yet implemented")
                }

                override fun onCancelled(error: DatabaseError) {
                    TODO("Not yet implemented")
                }

            })

            sendButtonPost.setOnClickListener {

                val imm: InputMethodManager =
                    getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.hideSoftInputFromWindow(writeCommentPost.windowToken, 0);

                fireReference("comments/${itemId}").push()
                    .setValue(Comment(user?.nickname, writeCommentPost.text.toString()))

                adapter.notifyDataSetChanged()

                writeCommentPost.setText(null)


            }

            wholeLayoutPost.setOnClickListener {
                hideKeyboard()
            }
            getCurrentUser { _, response ->
                user = response.body()
            }
            // 경매 신청
            applyAuctionTextPost.setOnClickListener {

                applyAuctionDialog.show()
                applyAuctionBind.apply {
                    getCurrentUser { _, response ->
                        user = response.body()
                        priceText.text = formattedPoint(user?.point?.minus(500))
                    }
                    guideText.text = str(R.string.apply_question)
                    infoText.text =
                        str(R.string.auction_fee) + "500P" + str(R.string.decrease_guide)
                    remainInfoText.text = str(R.string.apply_leftover)
                    acceptButton.text = str(R.string.apply_auction)
                    acceptButton.backgroundTintList =
                        ColorStateList.valueOf(color(splitties.material.colors.R.color.blue_800))
                    acceptButton.setOnClickListener {
                        acceptButton.isClickable = false
                        registerAuction(itemId, { _, _ ->
                            acceptButton.isClickable = true
                        }) { _, _ ->
                            applyAuctionDialog.dismiss()
                            applyAuctionTextPost.gone()
                        }
                        val nextIntent =
                            Intent(this@AuctionPostActivity, AuctionIngActivity::class.java)
                        nextIntent.putExtra("itemId", itemId)
                        startActivity(nextIntent)
                    }
                }

            }

            // 즉시 구매
            buyNowTextPost.setOnClickListener {
                buyNowDialog.show()
                buyNowBind.apply {
                    guideText.text = str(R.string.buy_question)
                    infoText.text =  currentPointTextPost.text.toString()+"가 " + str(R.string.decrease_guide)
                    remainInfoText.text = str(R.string.buy_leftover)
                    acceptButton.setOnClickListener {
                        buyNowDialog.dismiss()
                    }
                }

            }


            backButtonPost.setOnClickListener {
                onBackPressed()
            }
        }
    }


    private fun hideKeyboard() {
        val imm: InputMethodManager =
            getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(currentFocus?.windowToken, 0)
    }

}

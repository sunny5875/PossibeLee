package com.possiblee.kakaologin.view.login.main.home

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.setPadding
import com.possiblee.kakaologin.R
import com.possiblee.kakaologin.databinding.ActivityItemRegisterBinding
import com.possiblee.kakaologin.dto.ItemDto
import com.possiblee.kakaologin.dto.MutableByte
import com.possiblee.kakaologin.lib.*
import com.possiblee.kakaologin.network.RetrofitClient.registerItem
import com.possiblee.kakaologin.network.RetrofitClient.registerTestItem
import splitties.resources.color
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

class ItemRegisterActivity : AppCompatActivity() {

    private val bind by lazy {
        ActivityItemRegisterBinding.inflate(layoutInflater)
    }

    private val checkedIndex = MutableByte(null)


    private var currentBitmap: Bitmap? = null

    val CAMERA = Manifest.permission.CAMERA
    val READ_EXTERNAL_STORAGE = Manifest.permission.READ_EXTERNAL_STORAGE
    val WRITE_EXTERNAL_STORAGE = Manifest.permission.WRITE_EXTERNAL_STORAGE
    var currentPhotoPath = ""
    val REQUEST_IMAGE_CAPTURE = 1
    val PIC_CROP = 2

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        with(bind) {
            setContentView(root)
            radioGroup.setOnCheckedChangeListener{group, checkedId ->
                when(checkedId){
                    R.id.radioButton1 -> {
                        log("RADIO")
                        textView4.visibility = View.VISIBLE
                        categoryLayoutIR.root.visibility = View.VISIBLE
                        textView6.visibility = View.VISIBLE
                        periodRadioGroup.visibility = View.VISIBLE
                        textView7.visibility = View.VISIBLE
                        minPeopleGroup.visibility = View.VISIBLE
                        startPriceEditText.visibility = View.VISIBLE
                        okPriceEditText.visibility = View.VISIBLE


                    }
                    R.id.radioButton4 -> {
                        log("no")
                        textView4.visibility = View.GONE
                        categoryLayoutIR.root.visibility = View.GONE
                        textView6.visibility = View.GONE
                        periodRadioGroup.visibility = View.GONE
                        textView7.visibility = View.GONE
                        minPeopleGroup.visibility = View.GONE
                        startPriceEditText.visibility = View.GONE
                        okPriceEditText.visibility = View.GONE

                    }
                }
            }

            uploadImageRegister.setOnClickListener {
                requestPermission()
                if (checkPermission()) {
                    dispatchTakePictureIntent()
                }
            }

            categoryLayoutIR.setChildrenOnclickListener(checkedIndex, {
                it.mNameText = "해제됨"
            }) {
                it.mNameText = "체크됨"
            }
            backButtonIR.setOnClickListener {
                finish()
            }
            completeButton.setOnClickListener {
                // todo 필드 유효성 검사

                registerItem(
                    category = checkedIndex.value,
                    name = itemNameEditText.textString(),
                    description = descriptionEditText.textString(),
                    period = periodRadioGroup.checkedIndex().toByte(),
                    minPeople = minPeopleGroup.checkedIndex(),
                    startPrice = startPriceEditText.textString().toLong(),
                    okPrice = okPriceEditText.textString().toLongOrNull()
                ) { _, response ->
                    val itemDto: ItemDto = response.body() ?: return@registerItem
                    currentBitmap?.let {
                        registerTestItem(itemDto.id!!, it) { _, _ ->
                            finish()
                        }
                    }
                }
            }
        }
    }


    // 카메라 권한 요청
    private fun requestPermission() {
        ActivityCompat.requestPermissions(
            this, arrayOf(READ_EXTERNAL_STORAGE, CAMERA, WRITE_EXTERNAL_STORAGE),
            REQUEST_IMAGE_CAPTURE
        )
    }

    // 카메라 권한 체크
    private fun checkPermission(): Boolean {
        return (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)
    }

    // 권한요청 결과
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            Log.d(
                "TAG",
                "Permission: " + permissions[0] + "was " + grantResults[0] + "카메라 허가 받음 예이^^"
            )
        } else {
            Log.d("TAG", "카메라 허가 못받음 ㅠ 젠장!!")
        }
    }

    private fun performCrop(picUri: Uri) {
        try {
            val cropIntent = Intent("com.android.camera.action.CROP")
            // indicate image type and Uri
            cropIntent.setDataAndType(picUri, "image/*")
            // set crop properties here
            cropIntent.putExtra("crop", true)
            // indicate aspect of desired crop
            cropIntent.putExtra("aspectX", 1)
            cropIntent.putExtra("aspectY", 1)
            // indicate output X and Y
            cropIntent.putExtra("outputX", 128)
            cropIntent.putExtra("outputY", 128)
            // retrieve data on return
            cropIntent.putExtra("return-data", true)
            // start the activity - we handle returning in onActivityResult
            startActivityForResult(cropIntent, PIC_CROP)
        } // respond to users whose devices do not support the crop action
        catch (anfe: ActivityNotFoundException) {
            // display an error message
            val errorMessage = "Whoops - your device doesn't support the crop action!"
            val toast = Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT)
            toast.show()
        }
    }
    // 카메라 열기
    private fun dispatchTakePictureIntent() {
        Intent(MediaStore.ACTION_IMAGE_CAPTURE).also { takePictureIntent ->
            if (takePictureIntent.resolveActivity(this.packageManager) != null) {
                // 찍은 사진을 그림파일로 만들기
                val photoFile: File? =
                    try {
                        createImageFile()
                    } catch (ex: IOException) {
                        Log.d("TAG", "그림파일 만드는도중 에러생김")
                        null
                    }

                if (Build.VERSION.SDK_INT < 24) {
                    if (photoFile != null) {
                        val photoURI = Uri.fromFile(photoFile)
                        takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                    }
                } else {
                    // 그림파일을 성공적으로 만들었다면 onActivityForResult로 보내기
                    photoFile?.also {
                        val photoURI: Uri = FileProvider.getUriForFile(
                            this,
                            "com.possiblee.kakaologin.view.login.main.home.fileprovider",
                            it
                        )
                        takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                    }
                }

                val intent = Intent(Intent.ACTION_PICK)
                intent.type = "image/*"
//                intent.putExtra("crop", true)

                val chooserIntent = Intent.createChooser(intent, "전환할 앱을 선택해주세요.")
                chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(takePictureIntent))
                startActivityForResult(chooserIntent, REQUEST_IMAGE_CAPTURE)
            }
        }
    }


    // 카메라로 촬영한 이미지를 파일로 저장해준다
    @Throws(IOException::class)
    private fun createImageFile(): File {
        // Create an image file name
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
        val storageDir: File? = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile(
            "JPEG_${timeStamp}_", /* prefix */
            ".jpg", /* suffix */
            storageDir /* directory */
        ).apply {
            // Save a file: path for use with ACTION_VIEW intents
            currentPhotoPath = absolutePath
        }
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        when (requestCode) {
            1 -> {
                if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == Activity.RESULT_OK) {

                    // 정사각형으로 크롭 후 저장
                    data?.data?.let { uri ->
                        performCrop(uri)
                    }
                    var photoUri = data?.data
                    bind.uploadImageRegister.setImageURI(photoUri)
                    bind.plusImageRegister.gone()

//                     크롭없이 그냥 저장하는 버전
//                    data?.data?.let {
//                        uri -> bind.uploadImageRegister.setImageURI(uri)
//                        bind.plusImageRegister.gone()
//                    }
                }

                // 카메라로부터 받은 데이터가 있을경우에만
                val file = File(currentPhotoPath)
                val selectedUri = Uri.fromFile(file)
                try {
                    selectedUri?.let {
                        if (Build.VERSION.SDK_INT < 28) {
                            val bitmap = MediaStore.Images.Media
                                .getBitmap(contentResolver, selectedUri)  //Deprecated
                            bitmap?.apply {
                                currentBitmap = this
                                bind.uploadImageRegister.setImageBitmap(bitmap)
                                bind.uploadImageRegister.setPadding(0)
                                bind.plusImageRegister.gone()
                            }
                        } else {
                            val decode = ImageDecoder.createSource(contentResolver, selectedUri)
                            val bitmap = ImageDecoder.decodeBitmap(decode)
                            bitmap?.apply {
                                currentBitmap = this
                                bind.uploadImageRegister.setImageBitmap(bitmap)
                                bind.uploadImageRegister.setPadding(0)
                                bind.plusImageRegister.gone()
                            }
                        }
                    }
                } catch (e: java.lang.Exception) {
                    e.printStackTrace()
                }
            }

            2-> {
                // get the returned data
                val extras: Bundle = data?.extras!!
                // get the cropped bitmap
                val selectedBitmap = extras.getParcelable<Bitmap>("data")
                currentBitmap = selectedBitmap
                bind.uploadImageRegister.setImageBitmap(selectedBitmap)
                bind.uploadImageRegister.setPadding(0)
                bind.plusImageRegister.gone()
            }
        }
    }
}
package com.possiblee.kakaologin.view.login.main

import android.content.Context
import android.os.Bundle
import android.view.inputmethod.InputMethodManager
import androidx.appcompat.app.AppCompatActivity
import com.possiblee.kakaologin.R
import com.possiblee.kakaologin.databinding.ActivityAuctionIngBinding
import com.possiblee.kakaologin.dto.Comment
import com.possiblee.kakaologin.dto.User
import com.possiblee.kakaologin.lib.*
import com.possiblee.kakaologin.network.RetrofitClient.getCurrentUser
import com.possiblee.kakaologin.network.RetrofitClient.getItem
import splitties.bundle.BundleSpec
import splitties.bundle.bundle
import splitties.bundle.withExtras
import splitties.resources.str
import java.util.*

class AuctionIngActivity : AppCompatActivity() {

    private val bind by lazy {
        ActivityAuctionIngBinding.inflate(layoutInflater)
    }

    val adapter = ChatAdapter(this)
    var user = User()

    object Extras : BundleSpec() {
        var itemId: Int by bundle()
    }

    private val itemId by lazy {
        withExtras(Extras) {
            itemId
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        with(bind) {
            setContentView(root)
            refresh()

            sendButtonIng.setOnClickListener {
                val imm: InputMethodManager =
                    getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.hideSoftInputFromWindow(enterMoneyEditTextIng.windowToken, 0);
                getCurrentUser { _, response ->
                    user = response.body()!!
                }
                adapter.addComment(
                    Comment(
                        user.nickname,
                        enterMoneyEditTextIng.text.toString(),
                        Date()
                    )
                )
                adapter.notifyDataSetChanged()

                enterMoneyEditTextIng.setText(null)
            }

            chatRecyclerView.setOnClickListener {
                hideKeyboard()
            }

            backButtonIng.setOnClickListener {
                onBackPressed()
            }
        }
    }


    private fun hideKeyboard() {
        val imm: InputMethodManager =
            getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(currentFocus?.windowToken, 0)
    }

    fun refresh() {
        with(bind) {
            getItem(itemId) { _, response ->
                val item = response.body() ?: return@getItem finish()
                titleTextIng.text = str(R.string.item_name_auction, item.name)
                salerNameTextIng.text = item.userNickName
                participantsTextIng.text = "${item.people}"
                startPriceTextIng.text = formattedPoint(item.startPrice)
                okPriceText.text = formattedPoint(item.okPrice)
                currentPriceText.text = formattedPoint(item.currentPrice)

            }
            getCurrentUser { _, response ->
                val user = response.body() ?: return@getCurrentUser finish()
                myPointTextIng.text = formattedPoint(user.point)
            }
        }
    }
}
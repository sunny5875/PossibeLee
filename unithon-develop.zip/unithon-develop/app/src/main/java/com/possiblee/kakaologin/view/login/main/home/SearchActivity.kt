package com.possiblee.kakaologin.view.login.main.home

import android.os.Bundle
import android.widget.SearchView
import androidx.appcompat.app.AppCompatActivity
import com.possiblee.kakaologin.databinding.ActivityHomeSearchBinding
import com.possiblee.kakaologin.dto.Item
import com.possiblee.kakaologin.view.login.MainActivity
import com.possiblee.kakaologin.view.login.main.home.search.ItemAdapter

class SearchActivity : AppCompatActivity(){
    private val bind by lazy {
       ActivityHomeSearchBinding.inflate(layoutInflater)
    }


    private val itemAdapter by lazy {
        ItemAdapter(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        with(bind) {
            setContentView(root)

            searchItemRecycler.adapter = itemAdapter

            backButton.setOnClickListener {
                finish()
            }


        }
    }
}
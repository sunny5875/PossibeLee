package com.possiblee.kakaologin.view.login.main.home

import android.app.Activity
import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.possiblee.kakaologin.R
import com.possiblee.kakaologin.databinding.CellAuctionHotBinding
import com.possiblee.kakaologin.dto.ItemDto
import com.possiblee.kakaologin.lib.BASE_URL
import com.possiblee.kakaologin.lib.formattedPoint
import com.possiblee.kakaologin.lib.setTint
import com.possiblee.kakaologin.view.login.main.AuctionIngActivity
import com.possiblee.kakaologin.view.login.main.AuctionPostActivity
import splitties.activities.start
import splitties.bundle.putExtras
import splitties.resources.color

class HotAdapter(
    private val activity: Activity
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private var itemList: ArrayList<ItemDto> = arrayListOf()

    inner class ItemHolder(private val bind: CellAuctionHotBinding) :
        RecyclerView.ViewHolder(bind.root) {
        fun binding(itemDto: ItemDto, pos: Int) {
            with(bind) {
                Glide.with(activity).load("${BASE_URL}v1/upload?filename=${itemDto.id}").into(itemImageHot)
                itemTitleHot.text = itemDto.name
                currentPriceHot.text = activity.formattedPoint(itemDto.currentPrice)
                itemParticipantTextHot.text = itemDto.people.toString()
                if (itemDto.willEndAt == null) {
                    remainTimeHot.text = "경매 시작 전"
                    remainTimeImgHot.setTint(R.color.blue_grey_400)
                } else {

                    val time =
                        (itemDto.willEndAt.time - System.currentTimeMillis()) / 1000 / 60 / 60

                    remainTimeHot.text = "${time}시간 남음"
                }

                when (pos) {
                    0 -> {
                        itemDetailHot.text = "1"
                        itemDetailHot.backgroundTintList =
                            ColorStateList.valueOf(activity.color(splitties.material.colors.R.color.amber_300))
                    }

                    1 -> {
                        itemDetailHot.text = "2"
                        itemDetailHot.backgroundTintList =
                            ColorStateList.valueOf(activity.color(splitties.material.colors.R.color.grey_300))
                    }

                    2 -> {
                        itemDetailHot.text = "3"
                        itemDetailHot.backgroundTintList =
                            ColorStateList.valueOf(activity.color(splitties.material.colors.R.color.brown_200))
                    }

                    3 -> {
                        itemDetailHot.text = ""
                        itemDetailHot.backgroundTintList =
                            ColorStateList.valueOf(activity.color(R.color.transparent))
                    }

                    4 -> {
                        itemDetailHot.text = ""
                        itemDetailHot.backgroundTintList =
                            ColorStateList.valueOf(activity.color(R.color.transparent))
                    }

                    5 -> {
                        itemDetailHot.text = ""
                        itemDetailHot.backgroundTintList =
                            ColorStateList.valueOf(activity.color(R.color.transparent))
                    }

                    6 -> {
                        itemDetailHot.text = ""
                        itemDetailHot.backgroundTintList =
                            ColorStateList.valueOf(activity.color(R.color.transparent))
                    }

                    7 -> {
                        itemDetailHot.text = ""
                        itemDetailHot.backgroundTintList =
                            ColorStateList.valueOf(activity.color(R.color.transparent))
                    }

                    8 -> {
                        itemDetailHot.text = ""
                        itemDetailHot.backgroundTintList =
                            ColorStateList.valueOf(activity.color(R.color.transparent))
                    }

                    9 -> {
                        itemDetailHot.text = ""
                        itemDetailHot.backgroundTintList =
                            ColorStateList.valueOf(activity.color(R.color.transparent))
                    }

                    10 -> {
                        itemDetailHot.text = ""
                        itemDetailHot.backgroundTintList =
                            ColorStateList.valueOf(activity.color(R.color.transparent))
                    }

                }


                itemView.setOnClickListener {
                    when (itemDto.status) {
                        ItemDto.STATUS_CONTINUE -> {
                            activity.start<AuctionIngActivity> {
                                putExtras(AuctionIngActivity.Extras) {
                                    itemId = itemDto.id!!
                                }
                            }
                        }
                        else -> {
                            activity.start<AuctionPostActivity> {
                                putExtras(AuctionPostActivity.Extras) {
                                    itemId = itemDto.id!!
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val layoutInflater = LayoutInflater.from(activity)
        return ItemHolder(
            CellAuctionHotBinding.inflate(layoutInflater, parent, false)
        )
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        (holder as ItemHolder).binding(itemList[position], position)
    }

    override fun getItemCount(): Int {
        return itemList.size
    }

    fun refresh(itemList: ArrayList<ItemDto>) {
        this.itemList = itemList
        notifyDataSetChanged()
    }


}
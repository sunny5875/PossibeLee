package com.possiblee.kakaologin.view.login

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.kakao.sdk.auth.TokenManager
import com.kakao.sdk.user.UserApiClient
import com.possiblee.kakaologin.databinding.ActivitySignUpBinding
import com.possiblee.kakaologin.network.RetrofitClient.signUp
import com.possiblee.kakaologin.preference.UserPreferences

class SignUpActivity : AppCompatActivity() {

    private val bind by lazy {
        ActivitySignUpBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        with(bind) {
            setContentView(root)
            UserApiClient.instance.me { user, error ->
                if (error == null && user != null) {
                    nicknameEditText.setText("${user.kakaoAccount?.profile?.nickname}")
                }
            }
            signUpButton.setOnClickListener {
                signUp(
                    TokenManager.instance.getToken()?.accessToken!!,
                    nicknameEditText.text.toString()
                ) { _, response ->
                    UserPreferences.serverAccessToken = response.body()?.serverAccessToken
                    finish()
                }
            }
        }
    }
}
package com.possiblee.kakaologin.view.login.main.home

import android.app.Activity
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.possiblee.kakaologin.databinding.CellAuctionCommentBinding
import com.possiblee.kakaologin.dto.Comment
import com.possiblee.kakaologin.view.login.main.AuctionPostActivity
import okhttp3.internal.Util
import splitties.activities.start
import splitties.bundle.putExtras
import java.text.SimpleDateFormat
import java.time.format.DateTimeFormatter
import java.util.*
import kotlin.collections.ArrayList

class CommentAdapter(
    private val activity: Activity
) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>(){

    private var commentList: ArrayList<Comment> = arrayListOf()




    inner class commentHolder(private val bind: CellAuctionCommentBinding) :
        RecyclerView.ViewHolder(bind.root) {
        fun binding(comment: Comment) {
            with(bind) {
                val format = SimpleDateFormat("yyyy.MM.dd.EEEE")

                userNameTextComment.text = comment.userName
                dateTextComment.text =  format.format(Date())
                contentTextComment.text = comment.content
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val layoutInflater = LayoutInflater.from(activity)
        return commentHolder(
            CellAuctionCommentBinding.inflate(layoutInflater, parent, false)
        )
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        (holder as commentHolder).binding(commentList[position])
    }

    override fun getItemCount(): Int {
        return commentList.size
    }
    fun refresh(commentList: ArrayList<Comment>) {
        this.commentList = commentList
        notifyDataSetChanged()
    }
    fun addComment(comment: Comment) {
        this.commentList.add(comment)
        notifyDataSetChanged()
    }
}
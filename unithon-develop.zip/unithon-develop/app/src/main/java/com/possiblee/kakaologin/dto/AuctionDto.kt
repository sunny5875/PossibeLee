package com.possiblee.kakaologin.dto

data class AuctionDto(


    val id: Int? = null,
    val userId: Int? = null,
    val itemId: Int? = null
) {
    companion object {
    }
}
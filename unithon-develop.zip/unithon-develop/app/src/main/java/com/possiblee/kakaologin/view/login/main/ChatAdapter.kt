package com.possiblee.kakaologin.view.login.main


import android.app.Activity
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.possiblee.kakaologin.databinding.CellAuctionChatBinding
import com.possiblee.kakaologin.dto.Comment
import com.possiblee.kakaologin.view.login.main.AuctionPostActivity
import okhttp3.internal.Util
import splitties.activities.start
import splitties.bundle.putExtras
import java.text.SimpleDateFormat
import java.time.format.DateTimeFormatter
import java.util.*
import kotlin.collections.ArrayList

class ChatAdapter(
    private val activity: Activity
) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>(){

    private var chatList: ArrayList<Comment> = arrayListOf()
    
    inner class chatHolder(private val bind: CellAuctionChatBinding) :
        RecyclerView.ViewHolder(bind.root) {
        fun binding(comment: Comment) {
            with(bind) {
                val format = SimpleDateFormat("yyyy.MM.dd.EEEE")

                userNameTextAuctionChat.text = comment.userName
                chatContentTextAuctionChat.text= comment.content+"P를 제시하였습니다."
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val layoutInflater = LayoutInflater.from(activity)
        return chatHolder(
                    CellAuctionChatBinding.inflate(layoutInflater, parent, false)
        )
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        (holder as chatHolder).binding(chatList[position])
    }

    override fun getItemCount(): Int {
        return chatList.size
    }
    fun refresh(chatList: ArrayList<Comment>) {
        this.chatList = chatList
        notifyDataSetChanged()
    }
    fun addComment(comment: Comment) {
        this.chatList.add(comment)
        notifyDataSetChanged()
    }
    }

package com.possiblee.kakaologin.lib

const val BASE_URL = "http://3.35.8.20:8082/"

const val KAKAO_NATIVE_APP_KEY = "d03f98dd1bbbce68c13279a77af0a2c8"
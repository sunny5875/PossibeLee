package com.possiblee.kakaologin.view

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.FirebaseApp
import com.kakao.sdk.auth.AuthApiClient
import com.kakao.sdk.auth.TokenManager
import com.kakao.sdk.auth.model.OAuthToken
import com.kakao.sdk.user.UserApiClient
import com.possiblee.kakaologin.databinding.ActivityLoginBinding
import com.possiblee.kakaologin.lib.gone
import com.possiblee.kakaologin.lib.log
import com.possiblee.kakaologin.lib.show
import com.possiblee.kakaologin.network.RetrofitClient.kakaoLogin
import com.possiblee.kakaologin.preference.UserPreferences
import com.possiblee.kakaologin.view.login.MainActivity
import com.possiblee.kakaologin.view.login.SignUpActivity
import splitties.activities.start

class LoginActivity : AppCompatActivity() {

    private val bind by lazy {
        ActivityLoginBinding.inflate(layoutInflater)
    }


    private fun needLogin() {
        bind.kakaoLoginButton.show()
        bind.progressBar.gone()
    }

    private fun kakaoLoginSuccess() {
        kakaoLogin(TokenManager.instance.getToken()?.accessToken!!, { _, response ->
            when (response.code()) {
                400 -> {
                    needLogin()
                }
                404 -> {
                    start<SignUpActivity>()
                    finish()
                }
            }
        }) { _, response ->
            UserPreferences.serverAccessToken = response.body()?.serverAccessToken
            start<MainActivity>()
            finish()
        }
    }

    private val kakaoLoginCallback: (OAuthToken?, Throwable?) -> Unit = { token, error ->
        if (error == null && token != null) {
            kakaoLoginSuccess()
        } else {
            log(error)
            bind.progressBar.gone()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        with(bind) {
            setContentView(root)
            UserPreferences.serverAccessToken?.let {
                log("서버 액세스 토큰: $it")
                progressBar.show()
                start<MainActivity>()
                finish()
            } ?: let {
                if (AuthApiClient.instance.hasToken()) {
                    UserApiClient.instance.accessTokenInfo { _, error ->
                        if (error != null) {
                            needLogin()
                        } else {
                            kakaoLoginSuccess()
                        }
                    }
                } else {
                    needLogin()
                }
                kakaoLoginButton.setOnClickListener {
                    UserApiClient.instance.run {
                        progressBar.show()
                        if (isKakaoTalkLoginAvailable(this@LoginActivity)) {
                            loginWithKakaoTalk(this@LoginActivity, callback = kakaoLoginCallback)
                        } else {
                            loginWithKakaoAccount(this@LoginActivity, callback = kakaoLoginCallback)
                        }
                    }
                }
            }


        }
    }
}
package com.possiblee.kakaologin

import android.app.Application
import com.google.firebase.FirebaseApp
import com.kakao.sdk.common.KakaoSdk
import com.kakao.sdk.common.util.Utility
import com.possiblee.kakaologin.lib.KAKAO_NATIVE_APP_KEY
import com.possiblee.kakaologin.lib.log

class GlobalApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // 다른 초기화 코드들

        // Kakao SDK 초기화
        KakaoSdk.init(this, KAKAO_NATIVE_APP_KEY)
        log("키 해시: ${Utility.getKeyHash(this)}")
        FirebaseApp.initializeApp(this)

    }
}


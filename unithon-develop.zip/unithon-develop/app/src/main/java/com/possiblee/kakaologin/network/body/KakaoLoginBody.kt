package com.possiblee.kakaologin.network.body

data class KakaoLoginBody(
    val kakaoAccessToken: String? = null,
    val serverAccessToken: String? = null
)

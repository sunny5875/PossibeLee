package com.possiblee.kakaologin.network.body.send

data class ChangeNicknameBody(
    val nickname: String? = null
)

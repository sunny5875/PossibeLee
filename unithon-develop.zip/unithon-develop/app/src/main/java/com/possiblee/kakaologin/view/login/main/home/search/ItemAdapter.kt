package com.possiblee.kakaologin.view.login.main.home.search

import android.app.Activity
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.possiblee.kakaologin.R
import com.possiblee.kakaologin.databinding.CellAuctionItemBinding
import com.possiblee.kakaologin.dto.ItemDto
import com.possiblee.kakaologin.lib.*
import com.possiblee.kakaologin.view.login.main.AuctionIngActivity
import com.possiblee.kakaologin.view.login.main.AuctionPostActivity
import splitties.activities.start
import splitties.bundle.putExtras
import splitties.resources.str

class ItemAdapter(
    private val activity: Activity
) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>(), Filterable {

    private var itemList: ArrayList<ItemDto> = arrayListOf()
    private var filteredList = itemList


    inner class ItemDtoHolder(private val bind: CellAuctionItemBinding) :
        RecyclerView.ViewHolder(bind.root) {
        fun binding(itemDto: ItemDto) {
            with(bind) {
                Glide.with(activity).load("${BASE_URL}v1/upload?filename=${itemDto.id}")
                    .into(itemImageView)
                itemNameText.text = itemDto.name
                currentPriceText.text = activity.formattedPoint(itemDto.currentPrice)
                joinNumText.text = activity.str(
                    R.string.participantNumber,
                    itemDto.people,
                    ItemDto.PEOPLE_MAP.getValue(itemDto.minPeople!!)
                )

                if (itemDto.willEndAt == null) {
                    leftTimeText.text = "경매 시작 전"
                    imageView7.setTint(R.color.blue_grey_400)
                } else {

                    val time =
                        (itemDto.willEndAt.time - System.currentTimeMillis()) / 1000 / 60 / 60

                    leftTimeText.text = "${time}시간 남음"
                }
                likesNumText.text = "${itemDto.likes}"
                commentsNumText.text = "0"

                itemView.setOnClickListener {
                    when (itemDto.status) {
                        ItemDto.STATUS_CONTINUE -> {
                            activity.start<AuctionIngActivity> {
                                putExtras(AuctionIngActivity.Extras) {
                                    itemId = itemDto.id!!
                                }
                            }
                        }
                        else -> {
                            activity.start<AuctionPostActivity> {
                                putExtras(AuctionPostActivity.Extras) {
                                    itemId = itemDto.id!!
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val layoutInflater = LayoutInflater.from(activity)
        return ItemDtoHolder(
            CellAuctionItemBinding.inflate(layoutInflater, parent, false)
        )
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        (holder as ItemDtoHolder).binding(filteredList[position])
    }

    override fun getItemCount(): Int {

        return filteredList.size
    }


    override fun getFilter() = object : Filter() {
        override fun performFiltering(constraint: CharSequence?): FilterResults {
            lastConstraint = constraint?.toString()
            val checked = constraint?.toString()?.toByte()
            filteredList = itemList.filt {
                checked == null || it.status == checked
            } as ArrayList<ItemDto>
            return FilterResults()
        }

        override fun publishResults(p0: CharSequence?, p1: FilterResults?) {
            notifyDataSetChanged()
        }
    }

    var lastConstraint: String? = null
    fun refresh(itemList: ArrayList<ItemDto>, checked: CharSequence? = null) {
        this.itemList = itemList
        checked?.let {
            filter.filter(checked)
        } ?: run {
            filter.filter(lastConstraint)
        }

    }
}
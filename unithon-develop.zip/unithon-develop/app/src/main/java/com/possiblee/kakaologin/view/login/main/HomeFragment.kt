package com.possiblee.kakaologin.view.login.main

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.HorizontalScrollView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.fragment.app.Fragment
import com.possiblee.kakaologin.R
import com.possiblee.kakaologin.databinding.FragmentHomeBinding
import com.possiblee.kakaologin.lib.*
import com.possiblee.kakaologin.network.RetrofitClient.getItems
import com.possiblee.kakaologin.view.login.main.home.CategoriesActivity
import com.possiblee.kakaologin.view.login.main.home.HotAdapter
import com.possiblee.kakaologin.view.login.main.home.ItemRegisterActivity
import com.possiblee.kakaologin.view.login.main.home.search.ItemAdapter
import splitties.bundle.putExtras
import splitties.fragments.start
import splitties.resources.drawable


class HomeFragment constructor() : Fragment() {


    private lateinit var bind: FragmentHomeBinding


    private val parentActivity by lazy {
        requireActivity()
    }

    private val hotAdapter by lazy {
        HotAdapter(parentActivity)
    }

    private val itemAdapter by lazy {
        ItemAdapter(parentActivity)
    }



    private var isInit = false


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bind = FragmentHomeBinding.inflate(inflater, container, false)
        isInit = true
        with(bind) {

            ((categoryLayout.root.getChildAt(0) as HorizontalScrollView).getChildAt(0) as ConstraintLayout).let {
                repeat(it.childCount) { i ->
                    it.getChildAt(i).setOnClickListener {
                        start<CategoriesActivity> {
                            putExtras(CategoriesActivity.Extras) {
                                this.index = i.toByte()
                            }
                        }
                    }
                }
            }
            hotRecycler.adapter = hotAdapter
            itemRecyclerView.adapter = itemAdapter
            refresh()
            itemRegisterButton.setOnClickListener {
                start<ItemRegisterActivity>()
            }
            cellFilterLayout.periodRadioGroupCategories.setOnCheckedChangeListener { radioGroup, i ->
                radioGroup.isClickable = false
                refresh()
            }
            return root
        }
    }

    companion object {
        fun newInstance() = HomeFragment()
    }

    override fun onHiddenChanged(hidden: Boolean) {
        super.onHiddenChanged(hidden)
        if (isInit && !hidden) {
            refresh()
        }
    }

    override fun onStart() {
        super.onStart()
        if (isInit) {
            refresh()
        }
    }

    private val checkedOrderIndex
        get() = bind.cellFilterLayout.periodRadioGroupCategories.checkedIndex()

    fun refresh() {
        var sort: String? = null
        var order: String? = null
        when (checkedOrderIndex) {
            0 -> {
                sort = SORT_RECENT
                order = ORDER_DESC
            }
            1 -> {
                sort = SORT_LIKE
                order = ORDER_DESC
            }
            2 -> {
                sort = SORT_PRICE
                order = ORDER_DESC
            }
            3 -> {
                sort = SORT_PRICE
                order = ORDER_ASC
            }
        }
        parentActivity.getItems(sort = SORT_LIKE, order = ORDER_DESC, limit = 10) { call, response ->
            hotAdapter.refresh(response.body()!!)
        }
        parentActivity.getItems(sort = sort, order = order) { _, response ->
            itemAdapter.refresh(response.body()!!)
            bind.cellFilterLayout.periodRadioGroupCategories.isClickable = false
        }
    }


}
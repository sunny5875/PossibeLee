package com.possiblee.kakaologin.view.login.main.mypage

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import com.possiblee.kakaologin.databinding.ActivityTermsOfUseBinding

class TermsOfUseActivity : AppCompatActivity() {
    private val bind by lazy {
        ActivityTermsOfUseBinding.inflate(layoutInflater)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        with(bind){
            setContentView(root)

            backButtonIR.setOnClickListener {
                onBackPressed()
            }


            with(termsOfUseWebView){
                webViewClient = WebViewClient()
                settings.setSupportZoom(true)
                settings.javaScriptEnabled = true
                loadUrl("https://drive.google.com/file/d/1E0JPuHDMDvKjJSUZf_4-pdFHD9LGrC2t/view?usp=sharing")
            }

        }
    }
}
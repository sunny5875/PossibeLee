package com.possiblee.kakaologin.view.login.main

import android.content.res.ColorStateList
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.possiblee.kakaologin.R
import com.possiblee.kakaologin.databinding.BtmsheetNicknameBinding
import com.possiblee.kakaologin.databinding.BtmsheetNicknameBinding.inflate
import com.possiblee.kakaologin.databinding.FragmentEarnPointBinding
import com.possiblee.kakaologin.databinding.FragmentHomeBinding
import com.possiblee.kakaologin.databinding.FragmentMyPageBinding
import com.possiblee.kakaologin.network.RetrofitClient.changeNickname
import com.possiblee.kakaologin.network.RetrofitClient.getCurrentUser
import splitties.resources.color
import splitties.resources.str
import com.possiblee.kakaologin.view.login.main.mypage.TermsOfUseActivity
import splitties.fragments.start


class MyPageFragment constructor() : Fragment() {


    private lateinit var bind: FragmentMyPageBinding
    private lateinit var changeNicknameDialog: BottomSheetDialog
    private lateinit var changeNicknameBind: BtmsheetNicknameBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bind = FragmentMyPageBinding.inflate(inflater, container, false)
        changeNicknameDialog = BottomSheetDialog(requireContext())
        changeNicknameBind = BtmsheetNicknameBinding.inflate(inflater, container, false)
        changeNicknameDialog.setContentView(changeNicknameBind.root)
        with(bind) {


            requireActivity().getCurrentUser { _, response->
                val user = response.body()
                profileName.text= user!!.nickname
            }

            profileNameConstraint.setOnClickListener {
                changeNicknameDialog.show()
                changeNicknameBind.apply {
                     this.acceptButtonNickname.setOnClickListener {
                         val temp = textInputNickname.text.toString()
                        requireActivity().changeNickname(temp){_, response ->
                            profileName.text = temp
                        }

                        changeNicknameDialog.dismiss()
                    }
                }
            }


            termsOfUseConstraint.setOnClickListener {
                start<TermsOfUseActivity>()
            }


            return root
        }
    }

    companion object {
        fun newInstance() = MyPageFragment()
    }

    fun refresh() {
    }


}
package com.possiblee.kakaologin.network

import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import java.security.cert.CertPath

val database = Firebase.database("https://unithon-4c1cd-default-rtdb.asia-southeast1.firebasedatabase.app/")

fun fireReference(path: String) = database.getReference(path)
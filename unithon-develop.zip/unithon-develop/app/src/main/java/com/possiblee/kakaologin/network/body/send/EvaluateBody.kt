package com.possiblee.kakaologin.network.body.send

data class EvaluateBody(
    val winnerItemId: Int,
    val loserItemId: Int
)

package com.possiblee.kakaologin.network.api

import com.possiblee.kakaologin.dto.AuctionDto
import com.possiblee.kakaologin.dto.ItemDto
import com.possiblee.kakaologin.dto.User
import com.possiblee.kakaologin.network.body.KakaoLoginBody
import com.possiblee.kakaologin.network.body.SignUpBody
import com.possiblee.kakaologin.network.body.send.ChangeNicknameBody
import com.possiblee.kakaologin.network.body.send.EvaluateBody
import com.possiblee.kakaologin.network.body.send.RegisterAuctionBody
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.http.*

interface ServerApi {
    @POST("/v1/auth/kakao/login")
    fun kakaoLogin(
        @Body
        kakaoLoginBody: KakaoLoginBody
    ): Call<KakaoLoginBody>

    @POST("/v1/auth/signup")
    fun signUp(
        @Body
        signUpBody: SignUpBody
    ): Call<SignUpBody>

    @GET("/v1/user/me")
    fun getCurrentUser(
        @Header("Authorization")
        serverAccessToken: String
    ): Call<User>

    @PATCH("/v1/user/nickname")
    fun changeNickname(
        @Header("Authorization")
        serverAccessToken: String,
        @Body
        changeNicknameBody: ChangeNicknameBody
    ): Call<Void>

    @GET("/v1/item")
    fun getItem(
        @Header("Authorization")
        serverAccessToken: String,
        @Query("itemId")
        itemId: Int
    ): Call<ItemDto>

    @GET("/v1/item")
    fun getItems(
        @Header("Authorization")
        serverAccessToken: String,
        @Query("category")
        category: Byte?,
        @Query("sort")
        sort: String?,
        @Query("order")
        order: String?,
        @Query("limit")
        limit: Int?
    ): Call<ArrayList<ItemDto>>

    @GET("/v1/item/me")
    fun getMyItems(
        @Header("Authorization")
        serverAccessToken: String,
        @Query("type")
        type: String
    ): Call<ArrayList<ItemDto>>

    @Multipart
    @POST("/v1/item/registerTest")
    fun registerTestItem(
        @Header("Authorization")
        serverAccessToken: String,
        @Part
        data: MultipartBody.Part
    ): Call<Void>


    @POST("/v1/item/register")
    fun registerItem(
        @Header("Authorization")
        serverAccessToken: String,
        @Body
        itemDto: ItemDto
    ): Call<ItemDto>

    @POST("/v1/item/evaluate")
    fun evaluateItem(
        @Header("Authorization")
        serverAccessToken: String,
        @Body
        evaluateBody: EvaluateBody
    ): Call<Void>

    @POST("/v1/auction/register")
    fun registerAuction(
        @Header("Authorization")
        serverAccessToken: String,
        @Body
        registerAuctionBody: RegisterAuctionBody
    ): Call<Void>

    @GET("/v1/auction/me")
    fun getMyAuctions(
        @Header("Authorization")
        serverAccessToken: String
    ): Call<ArrayList<AuctionDto>>
}
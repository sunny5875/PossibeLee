package com.possiblee.kakaologin.common.view

import android.content.Context
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.View
import androidx.constraintlayout.widget.ConstraintLayout
import com.possiblee.kakaologin.R
import com.possiblee.kakaologin.databinding.CellCategoryBinding


class CategoryItemView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : ConstraintLayout(context, attrs, defStyleAttr) {


    var mCategoryImage: Drawable? = null
        set(value) {
            field = value
            requestLayout()
        }
    var mNameText = ""
        set(value) {
            field = value
            requestLayout()
        }
    var mBackground: Drawable? = null
        set(value) {
            field = value
            requestLayout()
        }

    init {
        initView()

        context.theme.obtainStyledAttributes(
            attrs,
            R.styleable.CategoryItemView,
            0, 0
        ).apply {

            try {
                mCategoryImage = getDrawable(R.styleable.CategoryItemView_categoryImage)
                mNameText = getString(R.styleable.CategoryItemView_nameText) ?: ""
            } finally {
                recycle()
            }
        }
    }

    private fun initView() {
        View.inflate(context, R.layout.cell_category, this)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        with(CellCategoryBinding.bind(this)) {
            mCategoryImage?.let {
                categoryImage.setImageDrawable(it)
            }
            nameText.text = mNameText
            mBackground?.let {
                categoryImage.background = mBackground
            }
        }
    }

}
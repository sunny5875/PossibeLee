package com.possiblee.kakaologin.dto

data class MutableByte(var value: Byte?)

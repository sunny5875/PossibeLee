package com.possiblee.kakaologin.view.login

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.children
import androidx.fragment.app.Fragment
import com.possiblee.kakaologin.R
import com.possiblee.kakaologin.databinding.ActivityMainBinding
import com.possiblee.kakaologin.lib.formattedPoint
import com.possiblee.kakaologin.lib.gone
import com.possiblee.kakaologin.lib.show
import com.possiblee.kakaologin.network.RetrofitClient.getCurrentUser
import com.possiblee.kakaologin.view.login.main.*
import com.possiblee.kakaologin.view.login.main.home.SearchActivity
import splitties.activities.start
import splitties.fragments.fragmentTransaction
import splitties.resources.str

class MainActivity : AppCompatActivity() {
    private val bind by lazy {
        ActivityMainBinding.inflate(layoutInflater)
    }

    private val homeFragment by lazy {
        HomeFragment.newInstance()
    }

    private val exchangeFragment by lazy {
        ExchangeFragment.newInstance()
    }

    private val earnPointFragment by lazy {
        EarnPointFragment.newInstance()
    }

    private val myPageFragment by lazy {
        MyPageFragment.newInstance()
    }

    var currentFragment: Fragment? = null

    companion object {
    }

    private fun replaceMainFrame(fragment: Fragment) {
        fragmentTransaction {
            currentFragment?.let { hide(it) }
            show(fragment)
            with(bind) {
                appBarConstraint.children.forEach {
                    it.gone()
                }
                when (fragment) {
                    homeFragment -> {
                        pointImage.show()
                        pointText.show()
                        searchButton.show()
                        titleText.show()
                        titleText.text = str(R.string.home)
                    }
                    exchangeFragment -> {
                        pointImage.show()
                        pointText.show()
                        titleText.show()
                        titleText.text = str(R.string.my_exchange)
                    }
                    earnPointFragment -> {
                        pointImage.show()
                        pointText.show()
                        titleText.show()
                        titleText.text = str(R.string.earn_point)
                    }
                    myPageFragment -> {
                        pointImage.show()
                        pointText.show()
                        titleText.show()
                        titleText.text = str(R.string.my_page)
                    }
                }
            }
            currentFragment = fragment
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        with(bind) {
            setContentView(root)
            refresh()
            fragmentTransaction {
                add(R.id.mainFrameFragment, homeFragment)
                hide(homeFragment)
                add(R.id.mainFrameFragment, exchangeFragment)
                hide(exchangeFragment)
                add(R.id.mainFrameFragment, earnPointFragment)
                hide(earnPointFragment)
                add(R.id.mainFrameFragment, myPageFragment)
                hide(myPageFragment)
            }
            replaceMainFrame(homeFragment)
            bottomNavigationView.setOnItemSelectedListener {
                when (it.itemId) {
                    R.id.homeItem -> {
                        replaceMainFrame(homeFragment)
                    }
                    R.id.exchangeItem -> {
                        replaceMainFrame(exchangeFragment)
                    }
                    R.id.earnPointItem -> {
                        replaceMainFrame(earnPointFragment)
                    }
                    R.id.myPageItem -> {
                        replaceMainFrame(myPageFragment)
                    }
                }
                true
            }

            searchButton.setOnClickListener {
                start<SearchActivity>()
            }
        }
    }
    fun refresh() {
        getCurrentUser { _, response ->
            val user = response.body()!!
            bind.pointText.text = formattedPoint(user.point)
        }
    }
}
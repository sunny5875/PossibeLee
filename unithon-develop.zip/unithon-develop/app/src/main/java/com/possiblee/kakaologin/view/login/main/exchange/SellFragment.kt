package com.possiblee.kakaologin.view.login.main.exchange

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.possiblee.kakaologin.databinding.FragmentEarnPointBinding
import com.possiblee.kakaologin.databinding.FragmentHomeBinding
import com.possiblee.kakaologin.databinding.FragmentSellBinding


class SellFragment constructor() : Fragment() {


    private lateinit var bind: FragmentSellBinding


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        bind = FragmentSellBinding.inflate(inflater, container, false)
        with(bind) {

            return root
        }
    }

    companion object {
        fun newInstance() = SellFragment()
    }

    fun refresh() {
    }


}
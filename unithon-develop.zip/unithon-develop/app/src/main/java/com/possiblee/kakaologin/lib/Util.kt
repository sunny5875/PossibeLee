package com.possiblee.kakaologin.lib

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.util.Log
import android.view.View
import android.widget.*
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.widget.ImageViewCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction
import com.possiblee.kakaologin.R
import com.possiblee.kakaologin.common.view.CategoryItemView
import com.possiblee.kakaologin.databinding.LayoutCategoryBinding
import com.possiblee.kakaologin.dto.MutableByte
import okhttp3.MediaType
import okhttp3.RequestBody
import splitties.resources.str
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat

fun log(any: Any?) = Log.d("jinha", "$any")

fun View.show() {
    visibility = View.VISIBLE
}

fun View.hide() {
    visibility = View.INVISIBLE
}

fun View.gone() {
    visibility = View.GONE
}

fun <T> ArrayList<T>.filt(a: (T) -> Boolean) = filter {
    a(it)
}

fun Bitmap.toRequestBody(): RequestBody {
    val stream = ByteArrayOutputStream()
    compress(Bitmap.CompressFormat.PNG, 100, stream)
    return RequestBody.create(MediaType.parse("application/octet-stream"), stream.toByteArray())
}

fun Byte?.toRequestBody() = RequestBody.create(MediaType.parse("text/plain"), toString())
fun String?.toRequestBody() = RequestBody.create(MediaType.parse("text/plain"), toString())
fun Int?.toRequestBody() = RequestBody.create(MediaType.parse("text/plain"), toString())
fun Long?.toRequestBody() = RequestBody.create(MediaType.parse("text/plain"), toString())

fun EditText.textString() = text.toString()

fun RadioGroup.checkedIndex(): Int = indexOfChild(findViewById(checkedRadioButtonId))

fun ImageView.setTint(color: Int) {
    ImageViewCompat.setImageTintList(this, ColorStateList.valueOf(color))
}

fun LayoutCategoryBinding.getContainer() = ((root.getChildAt(0) as HorizontalScrollView).getChildAt(0) as ConstraintLayout)
fun LayoutCategoryBinding.setChildrenOnclickListener(checkedIndex: MutableByte, unCheckedListener: (CategoryItemView) -> Unit, onClickListener: (CategoryItemView) -> Unit) {
    getContainer().let {
        repeat(it.childCount) { i ->
            it.getChildAt(i).setOnClickListener { view ->
                checkedIndex.value?.let { unchecked ->
                    unCheckedListener(it.getChildAt(unchecked.toInt()) as CategoryItemView)
                }
                checkedIndex.value = i.toByte()
                onClickListener(view as CategoryItemView)
            }
        }

    }
}

fun Context.formattedPoint(any: Any?) = str(R.string.point_string, "%,d".format(any))

inline fun Fragment.fragmentTransaction(
    now: Boolean = true,
    allowStateLoss: Boolean = false,
    transactionBody: FragmentTransaction.() -> Unit
): Unit = childFragmentManager.beginTransaction().apply(transactionBody).let { ft ->
    when {
        allowStateLoss -> if (now) ft.commitNowAllowingStateLoss() else ft.commitAllowingStateLoss()
        else -> if (now) ft.commitNow() else ft.commit()
    }
}